# TT.ControlPanel_keitaro_v_0_2
BOMJ PANEL v.0.2.0 - control your TT ADS account, and load cost in keitaro

TG: https://t.me/bearded_cpa
